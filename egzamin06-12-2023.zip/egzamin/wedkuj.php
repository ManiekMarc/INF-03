<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Wędkowanie</title>
    <link rel="stylesheet" href="styl_1.css">
</head>
<body>
    <div class=baner>
        <h1>Portal dla wędkarzy</h1>
    </div>

    <div class=lewy1>
        <h3>Ryby zamieszkujące rzeki<h3>
        <?php
            $polaczenie = mysqli_connect('localhost', 'root', '', 'wedkowanie');

            $zapytanie1 = "SELECT ryby.nazwa, lowisko.akwen, lowisko.wojewodztwo FROM `ryby`, `lowisko` WHERE ryby.id = lowisko.Ryby_id AND lowisko.rodzaj = 3";
            $wynik1 = mysqli_query($polaczenie, $zapytanie1);
            echo '<ol>';
            while($wiersz1 = mysqli_fetch_row($wynik1)){
                echo "<li>$wiersz1[0] pływa w rzece $wiersz1[1], $wiersz1[2]</li>";
            }
            echo '</ol>';
        ?>
    </div> 
    <div class=prawy>
        <img src="ryba1.jpg" alt="Sum"> 
        <br>
        <a href="kwerendy.txt">Pobierz kwerendy</a>   
    </div> 
    <div class=lewy2>
        <h3>Ryby drapieżnie naszych wód</h3>
        <table>
            <tr>
                <th>L.p.</th>
                <th>Gatunek</th>
                <th>Występowanie</th>
            <?php
                $zapytanie2 = 'SELECT `id`, `nazwa`, `wystepowanie` FROM `ryby` WHERE `styl_zycia` LIKE 1';
                $wynik2 = mysqli_query($polaczenie, $zapytanie2);

                while($wiersz2 = mysqli_fetch_row($wynik2)){
                    echo "<tr><td>$wiersz2[0]</td>
                        <td>$wiersz2[1]</td>
                        <td>$wiersz2[2]</td><tr>";
                }
            ?>
        </table>
    </div> 

    <div class=stopka>
        <p>Stronę wykonał: Marcel Żukociński</p>
    </div>
</body>
</html>